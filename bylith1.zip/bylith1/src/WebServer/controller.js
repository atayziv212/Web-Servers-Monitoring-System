const pool = require('../../db');
const queries = require('./queries');

const getWebservers = async (req, res) => {
    try {
        const results = await pool.query(queries.getWebservers);
        var webServers = new Map();
        const urlArray = results.rows;
        for (let i = 0; i < urlArray.length; i++) {
            let name = urlArray[i].name;
            const results2 = await pool.query(queries.getLast5requests, [name]);
            if (results2.rows[0].success_count == 5){
                webServers.set(name, 'Healthy');
                console.log(webServers);
            }
            else {
                console.log(name);
                const result3 = await pool.query(queries.getLast3requests, [name]);
                console.log(result3.rows[0]);
                if(result3.rows[0].unsuccess_count == 3) {
                    webServers.set(name, "Unhealthy");
                    console.log(webServers);
                }
            }
        }
        res.status(200).json(JSON.stringify([...webServers]));
    } catch (error) {
        console.log(error);
        res.status(500).send(error);
    }
};



const getWebServerById = (req,res) => {
    const name = req.params.name;
    pool.query(queries.getWebServerById, [name], (error,results)=>{
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};

const addWebServer = (req,res)=> {
    const {name , url} =req.body;
    //check if name exists
    pool.query(queries.checkNameExists,[name], (error,results) => {
        if(results.rows.length) {
            res.send("The name is already exists");
        }
        //add webServer
        pool.query(queries.addWebServer, [name,url], (error,results)=>{
            if(error) throw error;
            res.status(201).send("webServer Created Successfully");
        });
    });
};

const removeWebServer = (req,res) => {
    const name = req.params.name;
    pool.query(queries.getWebServerById, [name],(error,results) => {
        const noWebServerFound = !results.rows.length;
        if(noWebServerFound){
            res.send("Web Server does not exist in database");}
        pool.query(queries.removeWebServer,[name],(error,results) => {
            if(error) throw error;
            res.status(200).send("Web Server removed successfully");
        });
    });
};

const updateWebServer = (req,res) => {
    const name = req.params.id;
    const {url} =req.body;

    pool.query(queries.getWebServerById, [name], (error, results) => {
        const noWebServerFound = !results.rows.length;
        if(noWebServerFound){
            res.send("Web Server does not exist in database");}
        pool.query(queries.updateWebServer, [url , name] ,(error,results) => {
            if (error) throw error;
            res.status(200).send("Web server updated successfully");
        });
    });
};

const getWebServerHistory = (req,res) => {
    const name= req.params.name;
    pool.query(queries.getWebServerHistory, [name], (error,results)=>{
        if(error) throw error;
        res.status(200).json(results.rows);
    });
};


module.exports = {
    getWebservers,
    getWebServerById,
    addWebServer,
    removeWebServer,
    updateWebServer,
    getWebServerHistory,
};

