const getWebservers = "SELECT * FROM webservers" ;
const getWebServerById= "WITH last_10_calls AS (SELECT id, name, status,time FROM requestdb WHERE name = $1 ORDER BY id DESC LIMIT 10 ) SELECT webservers.id,webservers.name,webservers.url,last_10_calls.status,last_10_calls.time FROM webservers JOIN last_10_calls ON last_10_calls.name = webservers.name";
const checkNameExists = "SELECT s FROM webservers s WHERE s.name = $1 ";
const addWebServer = "INSERT INTO webservers (name,url) VALUES ($1,$2)";
const removeWebServer = "DELETE FROM webservers WHERE name = $1";
const updateWebServer = "UPDATE webservers SET url = $1 WHERE name = $2";
const getWebServerHistory = "SELECT * FROM requestdb WHERE name = $1";
const getLast5requests = "WITH last_5_calls AS (SELECT id, name, status FROM requestdb WHERE name = $1 ORDER BY id DESC LIMIT 5) SELECT COUNT(*) as success_count FROM last_5_calls WHERE status = 'success';"
const getLast3requests = "WITH last_3_calls AS (SELECT id, name, status FROM requestdb WHERE name = $1 ORDER BY id DESC LIMIT 3) SELECT COUNT(*) as unsuccess_count FROM last_3_calls WHERE status = 'Unsuccess';"

module .exports= {
    getWebservers,
    getWebServerById,
    checkNameExists,
    addWebServer,
    removeWebServer,
    updateWebServer,
    getWebServerHistory,
    getLast5requests,
    getLast3requests
};