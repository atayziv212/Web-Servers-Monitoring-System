const { Router } = require('express') ;

const router = Router();
const controller = require('./controller');


router.get('/' ,controller.getWebservers);
router.get("/:name",controller.getWebServerById);
router.post("/",controller.addWebServer);
router.delete("/:name",controller.removeWebServer);
router.put("/:name",controller.updateWebServer);
router.get('/history/:name', controller.getWebServerHistory);

module.exports=router;