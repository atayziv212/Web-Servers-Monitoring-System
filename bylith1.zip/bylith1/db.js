const Pool = require('pg').Pool;
const { performance } = require('perf_hooks');
const queries = require("./src/WebServer/queries"); //for the latency
const axios = require('axios');
const url=require("url");

const pool = new Pool({
    user : "postgres",
    host: "localhost",
    database: "webservers",
    password: "451997",
    port: 5432,
});

module.exports=pool;


setInterval(myTimer, 10000);
async function myTimer() {
    pool.connect();
    pool.query('SELECT url,name FROM webservers', async (err, res) => {
        if (err) throw err;
        const urlArray = res.rows;
        for (let i = 0; i < urlArray.length; i++) {
            let url = urlArray[i].url;
            let name= urlArray[i].name;
            try {
                var startTime = performance.now();
                const response = await makeRequest(url);
                var endTime = performance.now();
                var latency = (endTime - startTime) * 0.001;
                console.log(name);
                console.log(response.status);
                console.log(latency);
                if(response.status>=200 && response.status<300 && latency<60) {
                    pool.query("INSERT INTO requestdb (name,status,time) VALUES ($1,$2,NOW())", [name,'success'], (error, results) => {
                        if (error)
                            console.log(error);
                    });
                }
                else{
                    pool.query("INSERT INTO requestdb (name,status,time) VALUES ($1,$2,NOW())", [name,'Unsuccess'], (error, results) => {
                        if (error)
                            console.log(error);
                    });
                }
            } catch (error) {
                console.log(error);
                pool.query("INSERT INTO requestdb (name,status,time) VALUES ($1,$2,NOW())", [name,'Unsuccess'], (error, results) => {
                    if (error)
                        console.log(error);
                });
            }
        }
    });
}

async function makeRequest(url) {
    try {
        const response = await axios.get(url);
        return response;
    } catch (error) {
        throw error;
    }
}


